INCLUDE "include/hardware.inc"

SECTION "Input Variables", WRAM0
wCurKeys:: db


; Define la sección de interrupción por VBlank
; Al haber una interrupción por VBlank se hace un call a $40 y se deshabilitan las interrupciones (para evitar interrupción a la interrupción)
SECTION "VBlank Interrupt", ROM0[$40]
VBlankInterrupt: 
	reti ; Equivalente a ei + ret

; Luego del BOOT, el IP apunta a $100, por lo que hay que hacer un salto al entrypoint ya que en este lugar debe estar el header!
SECTION "Header", ROM0[$100]
    jp EntryPoint
    ds $150 - @, 0 ; Hay que hacer lugar para el header!

; En cualquier otro lugar de la ROM puede estar el código.
SECTION "Code", ROM0
;
; Función esperar hasta VBlank
WaitForVBlank::
    ;ld a, [rLY] ; En [rLY] está la línea que está "dibujando" la PPU. De 0 a 143 está dibujando la pantalla
    ;cp 144
    ;jp c, WaitForVBlank
	halt ;Espera a la interrupción de VBlank
	ret

;
; Función esperar a que VBlank termine
WaitVBlankEnd::
	ld a, [rLY] ; En [rLY] está la línea que está "dibujando" la PPU. De 144 a 153 está en VBlank
    cp 144 ; Cuando a>=144 (está en VBlank), no se setea C
    jp nc, WaitVBlankEnd
	ret

;
; Copia byte a byte de un orgen a un destino
; @param de: Origen
; @param hl: Destino
; @param bc: Longitud
Memcopy::
    ld a, [de]
    ld [hl+], a
    inc de
    dec bc
    ld a, b
    or a, c
    jp nz, Memcopy
	ret

;
; Apaga el LCD, tomando las precauciones necesarias
LCDOff:
	; NO APAGAR EL LCD FUERA DE VBLANK!
	ld a, [rLY]
    cp 144
    call c, WaitForVBlank
	; Apagar el LCD
	xor a, a ;ld a, 0
	ld [rLCDC], a
	ret 

;
; Prende el LCD
; @param a: Las banderas que se habilitan. Si es 0, por defecto se habilita el LCD, el fondo y los objetos
LCDOn:
		or a, a ; Básicamente comparar con 0 sin modificar a
		jp nz, .notDefault
		ld a, LCDCF_ON | LCDCF_BGON | LCDCF_OBJON
	.notDefault
		ld [rLCDC], a
		ret 
;
; Funcion que actualiza los botones presionados
; @ret wCurKeys: los botones actualmente presionados
UpdateKeys:
	ld a, $20	;Selecciono D-Pad
	ld [$FF00], a
	ld a, [$FF00]
	and a, $0F	;En el nibble más bajo quedan las direcciones seleccionadas
	swap a
	ld b, a
	ld a, $10	;Selecciono botones
	ld [$FF00], a
	ld a, [$FF00]
	and a, $0F	;En el nibble más bajo quedan los botones seleccionados
	or a, b		;En a queda todo el joypad, pero en sentido PULL-DOWN!
	xor a, $FF	;Invierto, para que quede en 1 lo presionado
	ld [wCurKeys], a ;Almaceno en una variable de la WRAM
	ret

;
; Acá inicializamos las cosas antes de hacer nada
EntryPoint:
	; Habilito interrupciones VBlank
	ld a, IEF_VBLANK
	ld [rIE], a
	xor a, a ;ld a, 0
	ld [rIF], a
	ei
    
	; HAY QUE APAGAR EL LCD PARA PODER HACER MODIFICACIONES GRANDES EN LA VRAM!
	call LCDOff

	; Copiar tiles de objetos
    ld de, SpriteSheet
    ld hl, $8000
    ld bc, SpriteSheetEnd - SpriteSheet
    call Memcopy

    ; Copiar tiles de fondo
    ld de, TileSet
    ld hl, $9000
    ld bc, TileSetEnd - TileSet
	call Memcopy

    ; Copiar tile map
    ld de, TileMap
    ld hl, $9800
    ld bc, TileMapEnd - TileMap
	call Memcopy

	; Inicializar paletas
	ld a, %11100100 ;Paleta del fondo
    ld [rBGP], a
	ld a, %11100100 ;Paleta de objetos
    ld [rOBP0], a

	; Limpio la memoria de atributos de objetos (OAM)
    xor a, a ;ld a, 0
    ld b, 160
    ld hl, _OAMRAM
ClearOam:
    ld [hl+], a
    dec b
    jp nz, ClearOam


	; Inicializar objeto 1
	ld hl, _OAMRAM
	ld a, 52 + 16
	ld [hl+], a ; Cargo posición en Y (ojo el offset!)
	ld a, 65 + 8
	ld [hl+], a ; Cargo posición en X (ojo el offset!)
	xor a, a ; ld a, 0
	ld [hl+], a ; Cargo índice del tile
	ld [hl+], a ; Cargo propiedades, como no hay nada que quiera cambiar se queda en 0

	; Inicializar objeto 2
	ld a, 92 + 16
	ld [hl+], a ; Cargo posición en Y (ojo el offset!)
	ld a, 100 + 8
	ld [hl+], a ; Cargo posición en X (ojo el offset!)
	ld a, 1
	ld [hl+], a ; Cargo índice del tile (el segundo!)
	xor a, a ; ld a, 0
	ld [hl+], a ; Cargo propiedades, como no hay nada que quiera cambiar se queda en 0

    xor a, a ;ld a, 0
	call LCDOn

	; Inicializar variables
    xor a, a ;ld a, 0
    ld [wCurKeys], a
	
;
; Bucle principal
Main:
    ; Se espera hasta que *no* sea VBlank, que es donde empieza un frame
	call WaitVBlankEnd
	; No se necesita estar en VBlank para esto
	call UpdateKeys


	; Se espera hasta que sea VBlank, que es donde podemos manipular la OAM
	call WaitForVBlank

	; Verifico el estado del JoyPad, y modifico la posición de los objetos
.verificaDer ;Etiqueda no usada, puesta sólo para mantener la estructura
	ld a, [wCurKeys]
	and a, PADF_RIGHT ; Verifico si el bit 4 está encendido
	jp z, .verificaIzq; Si es 0, no está presionado
	ld a, [_OAMRAM+4+1] ; Posición en X del segundo objeto
	inc a
	ld [_OAMRAM+4+1], a
.verificaIzq
	ld a, [wCurKeys]
	and a, PADF_LEFT ; Verifico si el bit 5 está encendido
	jp z, .verificaArr; Si es 0, no está presionado
	ld a, [_OAMRAM+4+1] ; Posición en X del segundo objeto
	dec a
	ld [_OAMRAM+4+1], a
.verificaArr
	ld a, [wCurKeys]
	and a, PADF_UP ; Verifico si el bit 6 está encendido
	jp z, .verificaAba; Si es 0, no está presionado
	ld a, [_OAMRAM+4+0] ; Posición en Y del segundo objeto
	dec a
	ld [_OAMRAM+4+0], a	
.verificaAba
	ld a, [wCurKeys]
	and a, PADF_DOWN ; Verifico si el bit 7 está encendido
	jp z, Main; Si es 0, no está presionado
	ld a, [_OAMRAM+4+0] ; Posición en Y del segundo objeto
	inc a
	ld [_OAMRAM+4+0], a
	
	jp Main




; Se ponen los datos gráficos en el segundo banco (el Nro $01)
SECTION "Graphic Data", ROMX
SpriteSheet:
	; Tile de moneda, expresado de a bytes como se escribiría
	db $38, $38, $7C, $44
	db $EE, $82, $CE, $8A
	db $CE, $8A, $FE, $92
	db $7C, $44, $38, $38
	; Otro tile, pero usando otra forma de escribirlo, más amigable
	dw `00000000
	dw `00033000
	dw `00311300
	dw `03111230
	dw `03112230
	dw `00322300
	dw `00033000
	dw `00000000
SpriteSheetEnd:

TileSet:
	; Tile completamente blanco
	dw `00000000
	dw `00000000
	dw `00000000
	dw `00000000
	dw `00000000
	dw `00000000
	dw `00000000
	dw `00000000
	; Tile completamente gris claro
	dw `11111111
	dw `11111111
	dw `11111111
	dw `11111111
	dw `11111111
	dw `11111111
	dw `11111111
	dw `11111111
TileSetEnd:

TileMap:
	; Un mapa simple de cuadrícula, entre blanco y gris claro
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0
	db 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0
	db 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0
TileMapEnd:
